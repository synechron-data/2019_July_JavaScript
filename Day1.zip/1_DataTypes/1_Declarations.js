'use strict'
// a = 20;
// console.log(a);

// function Check() {
//     var a = 10;
//     // a = 10;
//     console.log("Inside Fn, a is", a);
// }

// Check();
// console.log("Outside Fn, a is", a);

// var a = 10;
// var a = "ABC";
// console.log("a is: ", a);

var i = "Manish";
console.log("Before i is:", i);

function run() {
    for (var i = 0; i < 5; i++) {
        console.log("Inside i is:", i);
    }
}

run();

console.log("After i is:", i);
