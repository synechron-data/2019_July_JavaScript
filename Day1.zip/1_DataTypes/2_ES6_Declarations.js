'use strict'
// let a = 10;
// let a = "ABC";
// console.log("a is: ", a);

var i = "Manish";
console.log("Before i is:", i);

for (let i = 0; i < 5; i++) {
    console.log("Inside i is:", i);
}

console.log("After i is:", i);
