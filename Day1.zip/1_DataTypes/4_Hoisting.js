'use strict'

// i = 10;
// console.log(i);
// var i;

// console.log(i);
// var i;

// console.log(i);
// var i = 10;