'use strict'

var language;
console.log("Language is: " + language);
console.log("Type of Language is: " + typeof language);

language = null;
console.log("Language is: " + language);
console.log("Type of Language is: " + typeof language);

// language = "JavaScript";
// language = 'JavaScript';
language = `JavaScript`;
console.log("Language is: " + language);
console.log("Type of Language is: " + typeof language);

// language = 10;
// language = 10.5;
// language = Number.MAX_VALUE;
console.log("Language is: " + language);
// language += 1;
// console.log("Language is: " + language);
console.log("Type of Language is: " + typeof language);

language = true;
console.log("Language is: " + language);
console.log("Type of Language is: " + typeof language);

language = Symbol("abc");
console.log("Language is: ", language);
console.log("Type of Language is: ", typeof language);