'use strict'

var a = 45;
var b = "45";

var result1 = a == b;    // Abstract Equality
console.log(result1);

var result2 = a === b;    // Strict Equality
console.log(result2);

var obj1 = {};
// var obj2 = {};
var obj2 = obj1;
obj2.id = 10;

// console.log(obj1 == obj2);
// console.log(obj1 === obj2);

console.log(obj1);
console.log(obj2);

console.log(obj1 == obj2);
console.log(obj1 === obj2);