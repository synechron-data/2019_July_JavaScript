// Immediatly Invoked Function Expression (IIFE)

// function hello(name) {
//     console.log("Hello,", name);
// }

// hello("Synechron");

// (function (name) {
//     console.log("Hello,", name);
// })("Synechron");


var i = "Manish";
console.log("Before i is:", i);

// (function () {
//     for (var i = 0; i < 5; i++) {
//         console.log("Inside i is:", i);
//     }
// })();

(() => {
    for (var i = 0; i < 5; i++) {
        console.log("Inside i is:", i);
    }
})();

console.log("After i is:", i);