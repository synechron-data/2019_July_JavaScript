var add = (function () {
    function m1(x, y) {
        return x + y;
    }

    function m2(x, y, z) {
        return x + y + z;
    }

    return function () {
        if (arguments.length == 2)
            return m1(arguments[0], arguments[1]);
        else if (arguments.length == 3)
            return m2(arguments[0], arguments[1], arguments[2]);
        else
            throw Error("Invalid Parameters");
    }
})();

var r1 = add(2, 3);
console.log(r1);
var r2 = add(2, 3, 4);
console.log(r2);
