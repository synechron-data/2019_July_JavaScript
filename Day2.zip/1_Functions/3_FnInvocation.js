// function Check() {
//     console.log(arguments);
//     console.log(this);
// }

// // Invoking Function
// Check();
// Check.call();
// Check.apply();

// Resetting the context
// var p1 = { id: 1 };

// function Check(x, y) {
//     console.log(arguments);
//     console.log(this);
//     console.log(`x = ${x}, y = ${y}`);
// }

// // Invoking Function
// Check(2, 3);
// Check.call(p1, 2, 3);
// Check.apply(p1, [2, 3]);

// // Function Borrowing
// var e1 = {
//     id: 1,
//     name: "Manish",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// }

// var e2 = {
//     id: 2,
//     name: "Abhijeet",
//     display: function () {
//         console.log(JSON.stringify(this));
//     }
// }

// e1.display();
// e2.display();

// Function Borrowing
// var e1 = {
//     id: 1,
//     name: "Manish"
// }

// var e2 = {
//     id: 2,
//     name: "Abhijeet"
// }

// function display() {
//     console.log(JSON.stringify(this));
// }

// e1.display = display.bind(e1);
// e2.display = display.bind(e2);

// e1.display();
// e2.display();

// display.call(e1);
// display.call(e2);

// -------------------------------------
// function Person() {
//     this.age = 20;
//     this.growOld = function () {
//         console.log(this);
//         this.age += 1;
//     }
// }

// var p = new Person();
// // console.log(p);
// // p.growOld();
// // console.log(p.age);

// setInterval(p.growOld.bind(p), 1000);

// setInterval(function () {
//     console.log(p.age);
// }, 1000);

// --------------------------------------
function Person() {
    var self = this;
    self.age = 20;
    self.growOld = function () {
        self.age += 1;
    }
}

var p = new Person();

setInterval(p.growOld, 1000);

setInterval(function () {
    console.log(p.age);
}, 1000);