// function greetings(message, name) {
//     console.log(`${message}, ${name}`);
// }

// // greetings("Good Morning", "Abhijeet");
// // greetings("Good Morning", "Ramakant");
// // greetings("Good Morning", "Subodh");

// function Converter(toUnit, factor, offset, input) {
//     return [((offset + input) * factor).toFixed(2), toUnit].join("");
// }

// // console.log(Converter(' km', 1.6, 0, 20));
// // console.log(Converter(' km', 1.6, 0, 30));
// // console.log(Converter(' km', 1.6, 0, 40));
// // console.log(Converter(' km', 1.6, 0, 50));

// var mGreet = greetings.bind(this, "Good Morning");
// mGreet("Abhijeet");
// mGreet("Ramkant");
// mGreet("Subodh");

// var milesToKm = Converter.bind(this, ' km', 1.6, 0);
// console.log(milesToKm(20));
// console.log(milesToKm(30));
// console.log(milesToKm(40));
// console.log(milesToKm(50));

// ---------------------------

function greetings(message) {
    return function (name) {
        console.log(`${message}, ${name}`);
    }
}

var mGreet = greetings("Good Morning");
mGreet("Abhijeet");
mGreet("Ramkant");
mGreet("Subodh");

var gnGreet = greetings("Good Night");
gnGreet("Abhijeet");
gnGreet("Ramkant");
gnGreet("Subodh");