// var obj = null;
// var obj = new Object();
// var obj = {};
// console.log(obj);
// console.log(typeof obj);

// Object Literal - JavaScript Objects

var person = {
    id: 1,
    name: "Manish",
    city: "Pune",
    display: function () {
        console.log(this);
    }
};

// person.display();
// console.log(person);
// console.log(JSON.stringify(person));

var jsonperson = JSON.stringify(person);
var newperson = JSON.parse(JSON.stringify(person));
// console.log(newperson);

