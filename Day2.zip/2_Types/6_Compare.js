function getCounter(by) {
    var count = 0;
    return {
        next: function () {
            return count += by;
        },
        prev: function () {
            return count -= by;
        }
    };
}

function FnCounter(by) {
    this._count = 0;
    this._by = by;

    this.next = function () {
        return this._count += this._by;
    }

    this.prev = function () {
        return this._count -= this._by;
    }
}

var PTCounter = (function () {
    function PTCounter(by) {
        this._count = 0;
        this._by = by;
    }
    PTCounter.prototype.next = function () {
        return this._count += this._by;
    }

    PTCounter.prototype.prev = function () {
        return this._count -= this._by;
    }

    return PTCounter;
})();

class Counter {
    constructor(by) {
        this._count = 0;
        this._by = by;
    }

    next() {
        return this._count += this._by;
    }

    prev() {
        return this._count -= this._by;
    }
}

(function(){
    var clStTime = new Date();
    for (let i = 0; i < 2000000; i++) {
        var obj = getCounter(i);      
    }
    var clEnTime = new Date();

    var fnStTime = new Date();
    for (let i = 0; i < 2000000; i++) {
        var obj = new FnCounter(i);     
    }
    var fnEnTime = new Date();

    var ptStTime = new Date();
    for (let i = 0; i < 2000000; i++) {
        var obj = new PTCounter(i);     
    }
    var ptEnTime = new Date();

    var cStTime = new Date();
    for (let i = 0; i < 2000000; i++) {
        var obj = new Counter(i);     
    }
    var cEnTime = new Date();

    var clTime = clEnTime.getTime() - clStTime.getTime();
    var fnTime = fnEnTime.getTime() - fnStTime.getTime();
    var ptTime = ptEnTime.getTime() - ptStTime.getTime();
    var cTime = cEnTime.getTime() - cStTime.getTime();

    console.log("Closure: ", clTime, 'ms');
    console.log("Function: ", fnTime, 'ms');
    console.log("Prototype: ", ptTime, 'ms');
    console.log("Class: ", cTime, 'ms');
})();