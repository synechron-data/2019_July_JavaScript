// var Person = (function () {
//     function Person(name) {
//         this._name = name;
//     }

//     Object.defineProperty(Person.prototype, "Name", {
//         set: function (value) {
//             this._name = value;
//         },
//         get: function () {
//             return this._name;
//         }
//     })

//     return Person;
// })();

// var p1 = new Person("Manish");
// console.log(p1.Name);
// p1.Name = "Ramakant";
// console.log(p1.Name);

// var person = { id: 1, name: "Manish", city: "Pune" };

// for (const key in person) {
//     console.log(key);
// }

// Object.keys(person).forEach((key)=>{
//     console.log(key);
// });

// Object.getOwnPropertyNames(person).forEach((key) => {
//     console.log(key);
// });

var person = {};

Object.defineProperty(person, "id", {
    enumerable: true,
    writable: false,
    value: 1
});

Object.defineProperty(person, "name", {
    enumerable: true,
    value: "Manish"
});

person.id = 10;

for (const key in person) {
    console.log(`${key} ---- ${person[key]}`);
}
