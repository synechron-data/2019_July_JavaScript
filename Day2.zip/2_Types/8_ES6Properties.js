class Person {
    constructor(name) {
        this._name = name;
    }

    get Name() {
        return this._name;
    }

    set Name(value) {
        this._name = value;
    }

    static myMethod(){
        console.log("This is a static method");
    }
}

// var p1 = new Person("Manish");
// console.log(p1.getName());
// p1.setName("Ramakant");
// console.log(p1.getName());

Person.myMethod();