// let target = { a: 1, b: 2 };
// let source = { id: 1, name: "Manish", address: { city: "Pune" } };

// // let obj = Object.assign({}, source);   // Shallow Copy
// // console.log(obj === source);

// let obj = JSON.parse(JSON.stringify(source));

// obj.address.city = "Mumbai";
// console.log(source);
// console.log(obj);

// ------------------------------- Object.create
// Creates a new object, using an existing object as the prototype of the newly created object.
// const newSource = Object.create(source);
// console.log("Source: ", source);
// console.log("NewSource: ", newSource);

// ------------------------------- Object.freeze
let source = { id: 1, name: "Manish" };

// Object.freeze(source);
Object.preventExtensions(source);

if (Object.isExtensible(source))
    source.city = "Pune";

source.id = 100;
console.log(source);