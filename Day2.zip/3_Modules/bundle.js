(function () {
    'use strict';

    // Case 1 - Default Export
    // export default function square(x) {
    //     return x * x;
    // }

    // Case 2 - Named Export
    // export function square(x) {
    //     return x * x;
    // }

    // export function check(x) {
    //     return `Checked, ${x}`;
    // }

    // Case 3 - Default & Named
    function square(x) {
        return x * x;
    }

    function check(x) {
        return `Checked, ${x}`;
    }

    // Case 1 - Default Export
    console.log(square(20));
    console.log(check(20));

}());
