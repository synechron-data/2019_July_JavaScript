var person = { id: 1, name: "Manish", city: "Pune" };

// ES 5
// var id = person.id;
// var name = person.name;

// ES6 - Object Destrucring

// var { id, name } = person;
// console.log(id);
// console.log(name);

// ES6 - Array Destructuring

var arr = [10, 20, 30, 40, 50];

// ES5
// var x = arr[0];
// var y = arr[1];
var [x, , y] = arr;

console.log(`x = ${x}, y = ${y}`);