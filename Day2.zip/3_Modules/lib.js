// Case 1 - Default Export
// export default function square(x) {
//     return x * x;
// }

// Case 2 - Named Export
// export function square(x) {
//     return x * x;
// }

// export function check(x) {
//     return `Checked, ${x}`;
// }

// Case 3 - Default & Named
export default function square(x) {
    return x * x;
}

export function check(x) {
    return `Checked, ${x}`;
}