// Case 1 - Default Export
// import square from './lib';
// console.log(square(20));

// import sqr from './lib';
// console.log(sqr(20));

// Case 2 - Named Export
// import { square, check } from './lib';
// console.log(square(20));
// console.log(check(20));

// import * as lib from './lib';
// console.log(lib.square(200));
// console.log(lib.check(200));

// Case 3 - Default & Named 
import square, { check } from './lib';
console.log(square(20));
console.log(check(20));