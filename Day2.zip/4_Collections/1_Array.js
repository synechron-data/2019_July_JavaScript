// var employees = new Array();
// var employees = new Array(3);
// var employees = new Array("Manish");
// var employees = Array.of(3);
// var employees = ["Manish", "Abhijeet"];
var employees = Array.from("Manish");

// console.log(employees.length);

// for (let i = 0; i < employees.length; i++) {
//     console.log(`${i}  ----  ${employees[i]}`);    
// }

// for (const key in employees) {
//     console.log(`${key}  ----  ${employees[key]}`);    
// }

// ES 2015 - for of
for (const key of employees) {
    console.log(`${key}`);    
}