class Queue {
    constructor() {
        this._dataArray = [];
    }

    push(data) {
        this._dataArray.push(data);
    }

    pop() {
        return this._dataArray.shift();
    }

    // Generator
    *[Symbol.iterator]() {
        var self = this;
        yield* self._dataArray;
    }

    // Generator
    // *[Symbol.iterator]() {
    //     const self = this;
    //     for (let i = 0; i < self._dataArray.length; i++) {
    //         yield self._dataArray[i];
    //     }
    // }

    // [Symbol.iterator]() {
    //     const self = this;
    //     let i = 0;

    //     return {
    //         next: function () {
    //             let v, d = true;

    //             if (self._dataArray[i] !== undefined) {
    //                 v = self._dataArray[i];
    //                 d = false;
    //                 i += 1;
    //             }

    //             return {
    //                 value: v,
    //                 done: d
    //             };
    //         }
    //     };
    // }
}

var q = new Queue();
q.push(10);
q.push(20);
q.push(30);

for (const item of q) {
    console.log(item);
}

// console.log(q.pop());
// console.log(q.pop());
// console.log(q.pop());