// Dev 1
// var promise = new Promise((resolve, reject) => {
//     setTimeout(function () {
//         // resolve("It is a success");
//         reject("It is an error");
//     }, 2000);
// });

// Dev 2
// promise.then((data) => {
//     console.log(data);
// }, (err) => {
//     console.error(err);
// })

// promise.then((data) => {
//     console.log(data);
// }).catch((err) => {
//     console.error(err);
// });

// promise.then((data) => {
//     console.log(data);
// }).catch((err) => {
//     console.error(err);
// }).finally(()=>{
//     console.log("I will always run");
// })

// // 1. Function Returning Data
// function getString() {
//     const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];
//     var str = strArr[Math.floor(Math.random() * strArr.length)];
//     return str;
// }

// setInterval(function () {
//     console.log(getString());
// }, 2000);

// // 2. Function Pushing Data using callbacks
// function getString(cb) {
//     const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];

//     setInterval(function () {
//         var str = strArr[Math.floor(Math.random() * strArr.length)];
//         cb(str);
//     }, 2000);
// }

// getString(function (s) {
//     console.log(s);
// });

// 2. Function Pushing Data using Promise
function getString() {
    const strArr = ['NodeJS', 'ReactJS', 'AngularJS', 'ExtJS', 'VueJS'];

    var promise = new Promise((resolve,reject)=>{
        setTimeout(function () {
            var str = strArr[Math.floor(Math.random() * strArr.length)];
            resolve(str);
        }, 2000);
    });
    return promise;
}

getString().then(function (s) {
    console.log(s);
}).catch(function(err){
    console.error(err);
});