var firstMethod = function () {
    var promise = new Promise(function (resolve, reject) {
        setTimeout(function () {
            console.log('first method completed');
            resolve({ firstdata: '1' });
        }, 2000);
    });
    return promise;
};


var secondMethod = function () {
    var promise = new Promise(function (resolve, reject) {
        // setTimeout(function () {
        //     console.log('second method completed');
        //     resolve({ seconddata: '2' });
        // }, 2000);

        setTimeout(function () {
            reject("Error");
        }, 3000);
    });
    return promise;
};

var thirdMethod = function () {
    var promise = new Promise(function (resolve, reject) {
        setTimeout(function () {
            console.log('third method completed');
            resolve({ thirddata: '3' });
        }, 3000);
    });
    return promise;
};

// Promise.all([firstMethod(), secondMethod(), thirdMethod()]).then(data => {
//     console.log(data);
// }).catch((err)=>{
//     console.error(err);
// })

Promise.race([firstMethod(), secondMethod(), thirdMethod()]).then(data => {
    console.log(data);
}).catch((err) => {
    console.error(err);
})