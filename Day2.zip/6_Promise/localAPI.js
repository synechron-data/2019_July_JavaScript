var url = "https://jsonplaceholder.typicode.com/posts";

const localAPI = {
    getAllPosts: function () {
        var promise = new Promise((resolve, reject) => {
            fetch(url).then((response) => {
                response.json().then((data) => {
                    resolve(data);
                }, (err) => {
                    reject("Parsing Error");
                })
            }, (err) => {
                reject("Communication Error");
            })
        });
        return promise;
    }
}

localAPI.getAllPosts().then((data) => {
    console.log(data)
}).catch((err) => {
    console.error(err);
})